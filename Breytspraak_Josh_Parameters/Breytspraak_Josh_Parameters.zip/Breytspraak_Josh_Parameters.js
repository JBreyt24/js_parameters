// function greetSomeone(person) {
//     if (person == "Martin") {
//         console.log("Hello, partner!");
//     }
//     else {
//         console.log("Greetings, Earthling!");
//     }
// }
// greetSomeone("Martin");
// greetSomeone("Jerry");

//used above code as a template to get started



function greet(name, time) {
    if (name == "Count Dooku") {
        console.log("I'm coming for you, Dooku!");
    } else {
        console.log("Good " + time + " " + name + "!");

    }
}
greet("Anakin", "morning");
greet("Count Dooku", "day");